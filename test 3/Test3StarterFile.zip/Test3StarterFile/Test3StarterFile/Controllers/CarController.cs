﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Test3StarterFile.Models;

namespace Test3StarterFile.Controllers
{
    public class CarController : Controller
    {
        // GET: Car
        public ActionResult InventoryList()
        {
            ICarRepository repository = new EFCarRepository();
            IEnumerable<Car> Cars = repository.Cars;

            return View(Cars);

        }
    }
}